package kz.kazakhtime.zhapyraktusui;

import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.session.ClipboardHolder;
import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.flags.StateFlag;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedCuboidRegion;
import org.bukkit.*;
import org.bukkit.boss.*;
import org.bukkit.command.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import java.io.*;
import java.util.*;

public final class ZhapyrakTusui extends JavaPlugin implements Listener, CommandExecutor {
    private static final String LOOT_TITLE = "§6§lЖапырақ Түсуі §8| §fЛут";
    private final List<ItemStack> loot = new ArrayList<>();
    private final List<BlockVector3> markerOffsets = new ArrayList<>();
    private final List<BossBar> bars = new ArrayList<>();
    private Location eventCenter;
    private ProtectedCuboidRegion region;
    private BukkitTask task;
    private Phase phase = Phase.IDLE;
    private long phaseEnd;
    private int lootIndex;
    private List<Integer> markerOrder = new ArrayList<>();
    private int markerCursor;
    private String regionId;
    private final Map<Location, org.bukkit.block.data.BlockData> originalBlocks = new HashMap<>();

    enum Phase { IDLE, WAITING, LOOT, REMOVING }

    @Override public void onEnable() {
        saveDefaultConfig();
        loadLoot();
        getCommand("nevent").setExecutor(this);
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("ZhapyrakTusui enabled.");
    }

    @Override public void onDisable() { stopInternal(false); }

    @Override public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission("zhapyraktusui.admin")) { msg(s, "no-permission"); return true; }
        if (a.length == 0) { msg(s, "usage"); return true; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "start" -> { if (!(s instanceof Player p)) { s.sendMessage("Only players can start the event."); return true; } start(p.getLocation()); }
            case "stop" -> stop();
            case "loot" -> { if (!(s instanceof Player p)) return true; openLoot(p); }
            default -> msg(s, "usage");
        }
        return true;
    }

    private void start(Location center) {
        if (phase != Phase.IDLE) { msg(Bukkit.getConsoleSender(), "already-running"); return; }
        if (Bukkit.getPluginManager().getPlugin("WorldEdit") == null) { msg(Bukkit.getConsoleSender(), "missing-worldedit"); return; }
        if (loot.isEmpty()) { msg(Bukkit.getConsoleSender(), "loot-empty"); return; }
        try {
            File file = new File(getDataFolder(), getConfig().getString("schematic", "tree.schem"));
            if (!file.exists()) { msg(Bukkit.getConsoleSender(), "schematic-missing", Map.of("%file%", file.getName())); return; }
            Clipboard clipboard = readClipboard(file);
            markerOffsets.clear();
            Material marker = Material.matchMaterial(getConfig().getString("marker-block", "LIGHT"));
            if (marker == null) marker = Material.LIGHT;
            BlockVector3 min = clipboard.getRegion().getMinimumPoint();
            BlockVector3 max = clipboard.getRegion().getMaximumPoint();
            BlockVector3 origin = clipboard.getOrigin();
            for (int x=min.x(); x<=max.x(); x++) for (int y=min.y(); y<=max.y(); y++) for (int z=min.z(); z<=max.z(); z++) {
                var bs = clipboard.getBlock(BlockVector3.at(x,y,z));
                if (bs.getBlockType().getId().equalsIgnoreCase("minecraft:" + marker.name().toLowerCase(Locale.ROOT))) markerOffsets.add(BlockVector3.at(x-origin.x(), y-origin.y(), z-origin.z()));
            }
            if (markerOffsets.isEmpty()) { msg(Bukkit.getConsoleSender(), "no-markers", Map.of("%block%", marker.name())); return; }
            eventCenter = center.getBlock().getLocation().add(0.5, 0, 0.5);
            paste(clipboard, eventCenter);
            if (getConfig().getBoolean("region.enabled", true)) createRegion(eventCenter);
            lootIndex = 0; markerCursor = 0; refillMarkerOrder();
            phase = Phase.WAITING;
            phaseEnd = System.currentTimeMillis() + getConfig().getLong("timers.before-loot-seconds", 300) * 1000L;
            broadcast("started");
            startTicker();
        } catch (Exception ex) { getLogger().severe("Could not start event: " + ex.getMessage()); ex.printStackTrace(); stopInternal(false); }
    }

    private Clipboard readClipboard(File file) throws Exception {
        ClipboardFormat format = ClipboardFormats.findByFile(file);
        if (format == null) throw new IOException("Unknown schematic format");
        try (ClipboardReader reader = format.getReader(new FileInputStream(file))) { return reader.read(); }
    }

    private void paste(Clipboard clipboard, Location loc) throws Exception {
        originalBlocks.clear();
        boolean ignoreAir = getConfig().getBoolean("paste.ignore-air", true);
        BlockVector3 min = clipboard.getRegion().getMinimumPoint();
        BlockVector3 max = clipboard.getRegion().getMaximumPoint();
        BlockVector3 origin = clipboard.getOrigin();
        for (int x=min.x(); x<=max.x(); x++) for (int y=min.y(); y<=max.y(); y++) for (int z=min.z(); z<=max.z(); z++) {
            var bs = clipboard.getBlock(BlockVector3.at(x,y,z));
            if (ignoreAir && bs.getBlockType().getId().equalsIgnoreCase("minecraft:air")) continue;
            Location b = loc.getWorld().getBlockAt(loc.getBlockX()+x-origin.x(), loc.getBlockY()+y-origin.y(), loc.getBlockZ()+z-origin.z()).getLocation();
            if (originalBlocks.size() >= getConfig().getInt("paste.max-original-blocks",200000)) throw new IllegalStateException("Schematic is larger than paste.max-original-blocks");
            originalBlocks.put(b, b.getBlock().getBlockData().clone());
        }
        var weWorld = BukkitAdapter.adapt(loc.getWorld());
        try (EditSession edit = WorldEdit.getInstance().newEditSession(weWorld)) {
            Operations.complete(new ClipboardHolder(clipboard).createPaste(edit)
                    .to(BlockVector3.at(loc.getBlockX(), loc.getBlockY(), loc.getBlockZ()))
                    .ignoreAirBlocks(ignoreAir).build());
        }
        if (getConfig().getBoolean("paste.remove-markers-after-paste", true)) {
            for (BlockVector3 off : markerOffsets) loc.getWorld().getBlockAt(loc.getBlockX()+off.x(), loc.getBlockY()+off.y(), loc.getBlockZ()+off.z()).setType(Material.AIR, false);
        }
    }

    private void createRegion(Location c) throws Exception {
        if (Bukkit.getPluginManager().getPlugin("WorldGuard") == null) { msg(Bukkit.getConsoleSender(), "missing-worldguard"); return; }
        RegionManager rm = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(c.getWorld()));
        if (rm == null) return;
        int r = getConfig().getInt("region.radius", 30), minY=getConfig().getInt("region.min-y", -64), maxY=getConfig().getInt("region.max-y", 320);
        regionId = getConfig().getString("region.id", "zhapyrak_tusui") + "_" + c.getBlockX() + "_" + c.getBlockZ();
        region = new ProtectedCuboidRegion(regionId, BlockVector3.at(c.getBlockX()-r,minY,c.getBlockZ()-r), BlockVector3.at(c.getBlockX()+r,maxY,c.getBlockZ()+r));
        region.setPriority(getConfig().getInt("region.priority", 100));
        setFlag("build", Flags.BUILD, StateFlag.State.DENY); setFlag("pvp", Flags.PVP, StateFlag.State.DENY);
        setFlag("mob-spawning", Flags.MOB_SPAWNING, StateFlag.State.DENY); setFlag("creeper-explosion", Flags.CREEPER_EXPLOSION, StateFlag.State.DENY);
        setFlag("other-explosion", Flags.OTHER_EXPLOSION, StateFlag.State.DENY); setFlag("fire-spread", Flags.FIRE_SPREAD, StateFlag.State.DENY);
        setFlag("lava-fire", Flags.LAVA_FIRE, StateFlag.State.DENY); setFlag("leaf-decay", Flags.LEAF_DECAY, StateFlag.State.DENY);
        rm.addRegion(region); rm.save();
    }
    private void setFlag(String key, StateFlag flag, StateFlag.State fallback) { String v=getConfig().getString("region.flags."+key); region.setFlag(flag, "ALLOW".equalsIgnoreCase(v)?StateFlag.State.ALLOW:fallback); }

    private void startTicker() {
        if (task != null) task.cancel();
        task = Bukkit.getScheduler().runTaskTimer(this, this::tick, 0L, 10L);
    }
    private void tick() {
        if (phase == Phase.IDLE) return;
        long left = Math.max(0, phaseEnd-System.currentTimeMillis());
        updateBars(left);
        if (phase == Phase.WAITING && left <= 0) beginLoot();
        else if (phase == Phase.LOOT) {
            // The actual drop cycle is scheduled from phase start and preview is handled here.
            long elapsed = getConfig().getLong("timers.loot-duration-seconds",300)*1000L-left;
            long interval=getConfig().getLong("timers.drop-interval-seconds",5)*1000L;
            if (lootIndex < loot.size() && elapsed >= lootIndex*interval) scheduleDrop(lootIndex++);
            if (left <= 0) beginRemoving();
        } else if (phase == Phase.REMOVING && left <= 0) stopInternal(true);
    }

    private void beginLoot() { phase=Phase.LOOT; phaseEnd=System.currentTimeMillis()+getConfig().getLong("timers.loot-duration-seconds",300)*1000L; lootIndex=0; markerCursor=0; refillMarkerOrder(); broadcast("loot-start"); }
    private void beginRemoving() { phase=Phase.REMOVING; phaseEnd=System.currentTimeMillis()+getConfig().getLong("timers.remove-after-seconds",60)*1000L; broadcast("loot-end"); }

    private void scheduleDrop(int index) {
        if (markerCursor >= markerOrder.size()) refillMarkerOrder();
        int markerIndex=markerOrder.get(markerCursor++); Location loc=markerLocation(markerOffsets.get(markerIndex));
        long preview=Math.max(0, getConfig().getLong("timers.preview-seconds",3));
        showPreview(loc);
        Bukkit.getScheduler().runTaskLater(this, () -> drop(loot.get(index),loc), preview*20L);
    }
    private void drop(ItemStack stack, Location loc) {
        Item item=loc.getWorld().dropItem(loc.clone().add(0, getConfig().getDouble("drop.height",0.8), 0), stack.clone());
        item.setPickupDelay(getConfig().getInt("drop.pickup-delay-ticks",0));
        particle(loc,"drop"); sound(loc,"drop");
    }
    private void showPreview(Location loc) { particle(loc,"preview"); sound(loc,"preview"); }
    private Location markerLocation(BlockVector3 o) { return eventCenter.clone().add(o.x()+0.5,o.y(),o.z()+0.5); }
    private void refillMarkerOrder() { markerOrder=new ArrayList<>(); for(int i=0;i<markerOffsets.size();i++) markerOrder.add(i); Collections.shuffle(markerOrder); markerCursor=0; }

    private void particle(Location loc,String path) {
        try { Particle p=Particle.valueOf(getConfig().getString(path+".particle","FALLING_DUST"));
            int n=getConfig().getInt(path+".amount",18); double ox=getConfig().getDouble(path+".offset-x",getConfig().getDouble(path+".offset",0.35));
            double oy=getConfig().getDouble(path+".offset-y",getConfig().getDouble(path+".offset",0.35)); double oz=getConfig().getDouble(path+".offset-z",getConfig().getDouble(path+".offset",0.35));
            loc.getWorld().spawnParticle(p,loc,n,ox,oy,oz,getConfig().getDouble(path+".extra",0.08));
        } catch(Exception ignored) {}
    }
    private void sound(Location loc,String path) { try { loc.getWorld().playSound(loc, Sound.valueOf(getConfig().getString(path+".sound","ENTITY_ITEM_PICKUP")), (float)getConfig().getDouble(path+".sound-volume",1), (float)getConfig().getDouble(path+".sound-pitch",1)); } catch(Exception ignored) {} }

    private void updateBars(long left) {
        for(BossBar b:bars) b.removeAll(); bars.clear();
        double range=getConfig().getDouble("bossbars.range",30); String path=switch(phase){case WAITING->"before";case LOOT->"loot";case REMOVING->"remove";default->"before";};
        if(!getConfig().getBoolean("bossbars."+path+".enabled",true)) return;
        String title=color(getConfig().getString("bossbars."+path+".title","")); title=title.replace("%time%",format(left));
        BossBar b=Bukkit.createBossBar(title,BarColor.valueOf(getConfig().getString("bossbars."+path+".color","YELLOW")),BarStyle.valueOf(getConfig().getString("bossbars."+path+".style","SEGMENTED_20")));
        long total=switch(phase){case WAITING->getConfig().getLong("timers.before-loot-seconds",300);case LOOT->getConfig().getLong("timers.loot-duration-seconds",300);case REMOVING->getConfig().getLong("timers.remove-after-seconds",60);default->1;}; b.setProgress(Math.max(0,Math.min(1,left/1000.0/Math.max(1,total))));
        for(Player p:Bukkit.getOnlinePlayers()) if(p.getWorld().equals(eventCenter.getWorld())&&p.getLocation().distanceSquared(eventCenter)<=range*range) b.addPlayer(p); bars.add(b);
    }
    private String format(long ms){long s=(ms+999)/1000; return String.format("%02d:%02d",s/60,s%60);}

    private void stop() { if(phase==Phase.IDLE){msg(Bukkit.getConsoleSender(),"not-running");return;} stopInternal(true); }
    private void stopInternal(boolean announce) {
        if(task!=null){task.cancel();task=null;} for(BossBar b:bars)b.removeAll();bars.clear();
        if(region!=null&&eventCenter!=null&&Bukkit.getPluginManager().getPlugin("WorldGuard")!=null){try{RegionManager rm=WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(eventCenter.getWorld()));if(rm!=null&&regionId!=null){rm.removeRegion(regionId);rm.save();}}catch(Exception ignored){}}
        restoreOriginalBlocks();
        region=null; regionId=null; eventCenter=null; markerOffsets.clear(); originalBlocks.clear(); phase=Phase.IDLE; lootIndex=0; markerCursor=0;
        if(announce) broadcast("removed");
    }

    private void restoreOriginalBlocks() {
        if (originalBlocks.isEmpty()) return;
        for (var e : originalBlocks.entrySet()) {
            try { e.getKey().getBlock().setBlockData(e.getValue(), false); } catch (Exception ignored) {}
        }
    }

    private void broadcast(String key){List<String> lines=getConfig().getStringList("messages."+key);if(lines.isEmpty()){String one=getConfig().getString("messages."+key,"");lines=List.of(one);}for(String line:lines){line=color(line); if(line.equals("|")){Bukkit.broadcastMessage("");continue;} if(line.startsWith("|")) line=line.substring(1); if(line.endsWith("|")) line=line.substring(0,line.length()-1); Bukkit.broadcastMessage(line);} }
    private void msg(CommandSender s,String key){msg(s,key,Map.of());}
    private void msg(CommandSender s,String key,Map<String,String> repl){String m=getConfig().getString("messages."+key,"");for(var e:repl.entrySet())m=m.replace(e.getKey(),e.getValue());s.sendMessage(color(getConfig().getString("messages.prefix","")+m));}
    private String color(String s){return ChatColor.translateAlternateColorCodes('&',s==null?"":s);}

    private void openLoot(Player p){Inventory inv=Bukkit.createInventory(null,54,LOOT_TITLE);for(int i=0;i<loot.size()&&i<54;i++)inv.setItem(i,loot.get(i).clone());p.openInventory(inv);}
    @EventHandler public void onClose(InventoryCloseEvent e){if(!e.getView().getTitle().equals(LOOT_TITLE))return;loot.clear();for(ItemStack i:e.getInventory().getContents())if(i!=null&&!i.getType().isAir())loot.add(i.clone());saveLoot();e.getPlayer().sendMessage(color(getConfig().getString("messages.prefix","")+getConfig().getString("messages.loot-saved","&aSaved: %amount%").replace("%amount%",String.valueOf(loot.size()))));}
    @EventHandler public void onClick(InventoryClickEvent e){if(e.getView().getTitle().equals(LOOT_TITLE))return;}
    @EventHandler public void onQuit(PlayerQuitEvent e){for(BossBar b:bars)b.removePlayer(e.getPlayer());}

    private File lootFile(){return new File(getDataFolder(),"loot.yml");}
    private void loadLoot(){loot.clear();File f=lootFile();if(!f.exists())return;YamlConfiguration y=YamlConfiguration.loadConfiguration(f);for(Object o:y.getList("items",List.of()))if(o instanceof ItemStack i)loot.add(i.clone());}
    private void saveLoot(){YamlConfiguration y=new YamlConfiguration();y.set("items",loot);try{y.save(lootFile());}catch(IOException e){getLogger().warning("Could not save loot.yml: "+e.getMessage());}}
}
