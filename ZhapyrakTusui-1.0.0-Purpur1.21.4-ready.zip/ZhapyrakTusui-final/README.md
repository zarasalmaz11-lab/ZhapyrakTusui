# ZhapyrakTusui 1.0.0

Плагин ивента «Жапырақ Түсуі» для Purpur/Paper 1.21.4.

## Зависимости сервера
- Java 21
- Purpur 1.21.4
- WorldEdit 7.3.10
- WorldGuard 7.0.13

WorldEdit 7.3.10 и WorldGuard 7.0.13 выбраны именно для Minecraft 1.21.4.

## Сборка с телефона
Самый простой способ — GitHub Actions:
1. Создай репозиторий на GitHub.
2. Загрузи содержимое этого проекта.
3. Открой вкладку Actions.
4. Запусти `Build ZhapyrakTusui` через `Run workflow`.
5. После завершения открой успешный запуск → Artifacts → `ZhapyrakTusui-1.0.0`.
6. Внутри будет `ZhapyrakTusui-1.0.0.jar`.

## Локальная сборка
Требуется JDK 21 и Maven:
`mvn clean package`

JAR: `target/ZhapyrakTusui-1.0.0.jar`
